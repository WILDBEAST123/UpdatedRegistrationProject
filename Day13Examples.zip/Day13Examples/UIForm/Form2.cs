﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayer;

namespace UIForm
{
    public partial class Form2 : Form
    {
        RegistrationBAL bal = new RegistrationBAL();
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
           try
            {
                var res = bal.ShowEmpProject_Report();
                dataGridView1.DataSource = res.Tables["RegProj"];
                MessageBox.Show(res.GetXml());
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
