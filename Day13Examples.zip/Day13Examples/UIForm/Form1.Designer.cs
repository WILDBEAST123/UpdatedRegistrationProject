﻿namespace UIForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblName = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblNationality = new System.Windows.Forms.Label();
            this.lblQualification = new System.Windows.Forms.Label();
            this.lblSkillSets = new System.Windows.Forms.Label();
            this.lblHobbies = new System.Windows.Forms.Label();
            this.lblDoj = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.textAddress = new System.Windows.Forms.TextBox();
            this.textDob = new System.Windows.Forms.TextBox();
            this.textDoj = new System.Windows.Forms.TextBox();
            this.textSalary = new System.Windows.Forms.TextBox();
            this.txtDob = new System.Windows.Forms.DateTimePicker();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.lbQualification = new System.Windows.Forms.ListBox();
            this.lbSkillSets = new System.Windows.Forms.CheckedListBox();
            this.cbSwimming = new System.Windows.Forms.CheckBox();
            this.cbReading = new System.Windows.Forms.CheckBox();
            this.cbCooking = new System.Windows.Forms.CheckBox();
            this.cbMusic = new System.Windows.Forms.CheckBox();
            this.cbMobile = new System.Windows.Forms.CheckBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.cbNationality = new System.Windows.Forms.ComboBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnSelect = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnID = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSp = new System.Windows.Forms.Button();
            this.cbID = new System.Windows.Forms.ComboBox();
            this.registrationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trainingExampleDataSet = new UIForm.TrainingExampleDataSet();
            this.registrationTableAdapter = new UIForm.TrainingExampleDataSetTableAdapters.RegistrationTableAdapter();
            this.btnDataset = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.registrationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainingExampleDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblName.Location = new System.Drawing.Point(41, 30);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(63, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Enter Name";
            this.lblName.Click += new System.EventHandler(this.label1_Click);
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.BackColor = System.Drawing.SystemColors.ControlDark;
            this.Address.Location = new System.Drawing.Point(41, 90);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(45, 13);
            this.Address.TabIndex = 1;
            this.Address.Text = "Address";
            this.Address.Click += new System.EventHandler(this.Address_Click);
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lbldob.Location = new System.Drawing.Point(41, 155);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(58, 13);
            this.lbldob.TabIndex = 2;
            this.lbldob.Text = "Enter DOB";
            this.lbldob.Click += new System.EventHandler(this.lbldob_Click);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblGender.Location = new System.Drawing.Point(41, 257);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(75, 13);
            this.lblGender.TabIndex = 3;
            this.lblGender.Text = "Select Gender";
            this.lblGender.Click += new System.EventHandler(this.lblGender_Click);
            // 
            // lblNationality
            // 
            this.lblNationality.AutoSize = true;
            this.lblNationality.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblNationality.Location = new System.Drawing.Point(41, 322);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.Size = new System.Drawing.Size(89, 13);
            this.lblNationality.TabIndex = 4;
            this.lblNationality.Text = "Select Nationality";
            this.lblNationality.Click += new System.EventHandler(this.lblNationality_Click);
            // 
            // lblQualification
            // 
            this.lblQualification.AutoSize = true;
            this.lblQualification.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblQualification.Location = new System.Drawing.Point(273, 30);
            this.lblQualification.Name = "lblQualification";
            this.lblQualification.Size = new System.Drawing.Size(98, 13);
            this.lblQualification.TabIndex = 5;
            this.lblQualification.Text = "Select Qualification";
            // 
            // lblSkillSets
            // 
            this.lblSkillSets.AutoSize = true;
            this.lblSkillSets.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblSkillSets.Location = new System.Drawing.Point(273, 90);
            this.lblSkillSets.Name = "lblSkillSets";
            this.lblSkillSets.Size = new System.Drawing.Size(74, 13);
            this.lblSkillSets.TabIndex = 6;
            this.lblSkillSets.Text = "Slect SkillSets";
            // 
            // lblHobbies
            // 
            this.lblHobbies.AutoSize = true;
            this.lblHobbies.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblHobbies.Location = new System.Drawing.Point(273, 155);
            this.lblHobbies.Name = "lblHobbies";
            this.lblHobbies.Size = new System.Drawing.Size(79, 13);
            this.lblHobbies.TabIndex = 7;
            this.lblHobbies.Text = "Select Hobbies";
            // 
            // lblDoj
            // 
            this.lblDoj.AutoSize = true;
            this.lblDoj.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblDoj.Location = new System.Drawing.Point(273, 237);
            this.lblDoj.Name = "lblDoj";
            this.lblDoj.Size = new System.Drawing.Size(61, 13);
            this.lblDoj.TabIndex = 8;
            this.lblDoj.Text = "Select DOJ";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lblSalary.Location = new System.Drawing.Point(41, 388);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(64, 13);
            this.lblSalary.TabIndex = 9;
            this.lblSalary.Text = "Enter Salary";
            this.lblSalary.Click += new System.EventHandler(this.lblSalary_Click);
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(131, 30);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(100, 20);
            this.textName.TabIndex = 10;
            this.toolTip1.SetToolTip(this.textName, "Enter Your First Name");
            this.textName.TextChanged += new System.EventHandler(this.textName_TextChanged);
            // 
            // textAddress
            // 
            this.textAddress.Location = new System.Drawing.Point(131, 90);
            this.textAddress.Multiline = true;
            this.textAddress.Name = "textAddress";
            this.textAddress.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textAddress.Size = new System.Drawing.Size(100, 20);
            this.textAddress.TabIndex = 11;
            this.toolTip1.SetToolTip(this.textAddress, "Enter Your Address for comunication");
            this.textAddress.TextChanged += new System.EventHandler(this.textAddress_TextChanged);
            // 
            // textDob
            // 
            this.textDob.Location = new System.Drawing.Point(131, 155);
            this.textDob.Name = "textDob";
            this.textDob.ReadOnly = true;
            this.textDob.Size = new System.Drawing.Size(100, 20);
            this.textDob.TabIndex = 12;
            this.toolTip1.SetToolTip(this.textDob, "Enter date of birth");
            // 
            // textDoj
            // 
            this.textDoj.Location = new System.Drawing.Point(362, 230);
            this.textDoj.Name = "textDoj";
            this.textDoj.ReadOnly = true;
            this.textDoj.Size = new System.Drawing.Size(100, 20);
            this.textDoj.TabIndex = 13;
            // 
            // textSalary
            // 
            this.textSalary.Location = new System.Drawing.Point(131, 381);
            this.textSalary.Name = "textSalary";
            this.textSalary.Size = new System.Drawing.Size(100, 20);
            this.textSalary.TabIndex = 14;
            this.textSalary.TextChanged += new System.EventHandler(this.textSalary_TextChanged);
            // 
            // txtDob
            // 
            this.txtDob.Location = new System.Drawing.Point(131, 181);
            this.txtDob.Name = "txtDob";
            this.txtDob.Size = new System.Drawing.Size(100, 20);
            this.txtDob.TabIndex = 15;
            this.txtDob.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(257, 259);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 16;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbFemale);
            this.groupBox1.Controls.Add(this.rbMale);
            this.groupBox1.Location = new System.Drawing.Point(131, 237);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(100, 56);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Location = new System.Drawing.Point(6, 33);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(59, 17);
            this.rbFemale.TabIndex = 1;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            this.rbFemale.CheckedChanged += new System.EventHandler(this.rbFemale_CheckedChanged);
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Location = new System.Drawing.Point(6, 10);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(48, 17);
            this.rbMale.TabIndex = 0;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            this.rbMale.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // lbQualification
            // 
            this.lbQualification.FormattingEnabled = true;
            this.lbQualification.Items.AddRange(new object[] {
            "BE",
            "BTech",
            "MTech",
            "MS",
            "MBA",
            "Others"});
            this.lbQualification.Location = new System.Drawing.Point(377, 16);
            this.lbQualification.Name = "lbQualification";
            this.lbQualification.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lbQualification.Size = new System.Drawing.Size(148, 43);
            this.lbQualification.TabIndex = 19;
            // 
            // lbSkillSets
            // 
            this.lbSkillSets.FormattingEnabled = true;
            this.lbSkillSets.Items.AddRange(new object[] {
            "C#",
            "HTML",
            "Database",
            "JavaScript",
            "CSS",
            "ADO.NET",
            "ASP.NET",
            "MVC",
            "Projects",
            "SoftSkills"});
            this.lbSkillSets.Location = new System.Drawing.Point(377, 74);
            this.lbSkillSets.Name = "lbSkillSets";
            this.lbSkillSets.Size = new System.Drawing.Size(148, 34);
            this.lbSkillSets.TabIndex = 20;
            // 
            // cbSwimming
            // 
            this.cbSwimming.AutoSize = true;
            this.cbSwimming.Location = new System.Drawing.Point(377, 151);
            this.cbSwimming.Name = "cbSwimming";
            this.cbSwimming.Size = new System.Drawing.Size(73, 17);
            this.cbSwimming.TabIndex = 21;
            this.cbSwimming.Text = "Swimming";
            this.cbSwimming.UseVisualStyleBackColor = true;
            this.cbSwimming.CheckedChanged += new System.EventHandler(this.cbSwimming_CheckedChanged);
            // 
            // cbReading
            // 
            this.cbReading.AutoSize = true;
            this.cbReading.Location = new System.Drawing.Point(463, 151);
            this.cbReading.Name = "cbReading";
            this.cbReading.Size = new System.Drawing.Size(66, 17);
            this.cbReading.TabIndex = 22;
            this.cbReading.Text = "Reading";
            this.cbReading.UseVisualStyleBackColor = true;
            this.cbReading.CheckedChanged += new System.EventHandler(this.cbReading_CheckedChanged);
            // 
            // cbCooking
            // 
            this.cbCooking.AutoSize = true;
            this.cbCooking.Location = new System.Drawing.Point(377, 197);
            this.cbCooking.Name = "cbCooking";
            this.cbCooking.Size = new System.Drawing.Size(65, 17);
            this.cbCooking.TabIndex = 23;
            this.cbCooking.Text = "Cooking";
            this.cbCooking.UseVisualStyleBackColor = true;
            this.cbCooking.CheckedChanged += new System.EventHandler(this.cbCooking_CheckedChanged);
            // 
            // cbMusic
            // 
            this.cbMusic.AutoSize = true;
            this.cbMusic.Location = new System.Drawing.Point(463, 197);
            this.cbMusic.Name = "cbMusic";
            this.cbMusic.Size = new System.Drawing.Size(54, 17);
            this.cbMusic.TabIndex = 24;
            this.cbMusic.Text = "Music";
            this.cbMusic.UseVisualStyleBackColor = true;
            this.cbMusic.CheckedChanged += new System.EventHandler(this.cbMusic_CheckedChanged);
            // 
            // cbMobile
            // 
            this.cbMobile.AutoSize = true;
            this.cbMobile.Location = new System.Drawing.Point(276, 197);
            this.cbMobile.Name = "cbMobile";
            this.cbMobile.Size = new System.Drawing.Size(57, 17);
            this.cbMobile.TabIndex = 25;
            this.cbMobile.Text = "Mobile";
            this.cbMobile.UseVisualStyleBackColor = true;
            this.cbMobile.CheckedChanged += new System.EventHandler(this.cbMobile_CheckedChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSubmit.Location = new System.Drawing.Point(77, 430);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(89, 37);
            this.btnSubmit.TabIndex = 26;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click_1);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(296, 444);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 27;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // cbNationality
            // 
            this.cbNationality.FormattingEnabled = true;
            this.cbNationality.Items.AddRange(new object[] {
            "India",
            "US ",
            "UK",
            "America"});
            this.cbNationality.Location = new System.Drawing.Point(136, 319);
            this.cbNationality.Name = "cbNationality";
            this.cbNationality.Size = new System.Drawing.Size(109, 21);
            this.cbNationality.TabIndex = 28;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(463, 443);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 29;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(494, 257);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(161, 164);
            this.dataGridView1.TabIndex = 30;
            // 
            // btnID
            // 
            this.btnID.Location = new System.Drawing.Point(545, 13);
            this.btnID.Name = "btnID";
            this.btnID.Size = new System.Drawing.Size(75, 23);
            this.btnID.TabIndex = 31;
            this.btnID.Text = "SelectByID";
            this.btnID.UseVisualStyleBackColor = true;
            this.btnID.Click += new System.EventHandler(this.btnID_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(545, 42);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 32;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(545, 74);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 33;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSp
            // 
            this.btnSp.Location = new System.Drawing.Point(545, 103);
            this.btnSp.Name = "btnSp";
            this.btnSp.Size = new System.Drawing.Size(75, 23);
            this.btnSp.TabIndex = 34;
            this.btnSp.Text = "Call Sp";
            this.btnSp.UseVisualStyleBackColor = true;
            this.btnSp.Click += new System.EventHandler(this.btnSp_Click);
            // 
            // cbID
            // 
            this.cbID.DataSource = this.registrationBindingSource;
            this.cbID.DisplayMember = "Name";
            this.cbID.FormattingEnabled = true;
            this.cbID.Location = new System.Drawing.Point(119, 56);
            this.cbID.Name = "cbID";
            this.cbID.Size = new System.Drawing.Size(120, 21);
            this.cbID.TabIndex = 35;
            this.cbID.ValueMember = "RegID";
            // 
            // registrationBindingSource
            // 
            this.registrationBindingSource.DataMember = "Registration";
            this.registrationBindingSource.DataSource = this.trainingExampleDataSet;
            // 
            // trainingExampleDataSet
            // 
            this.trainingExampleDataSet.DataSetName = "TrainingExampleDataSet";
            this.trainingExampleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // registrationTableAdapter
            // 
            this.registrationTableAdapter.ClearBeforeFill = true;
            // 
            // btnDataset
            // 
            this.btnDataset.Location = new System.Drawing.Point(545, 145);
            this.btnDataset.Name = "btnDataset";
            this.btnDataset.Size = new System.Drawing.Size(75, 23);
            this.btnDataset.TabIndex = 36;
            this.btnDataset.Text = "Dataset";
            this.btnDataset.UseVisualStyleBackColor = true;
            this.btnDataset.Click += new System.EventHandler(this.btnDataset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(792, 479);
            this.Controls.Add(this.btnDataset);
            this.Controls.Add(this.cbID);
            this.Controls.Add(this.btnSp);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnID);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.cbNationality);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.cbMobile);
            this.Controls.Add(this.cbMusic);
            this.Controls.Add(this.cbCooking);
            this.Controls.Add(this.cbReading);
            this.Controls.Add(this.cbSwimming);
            this.Controls.Add(this.lbSkillSets);
            this.Controls.Add(this.lbQualification);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.txtDob);
            this.Controls.Add(this.textSalary);
            this.Controls.Add(this.textDoj);
            this.Controls.Add(this.textDob);
            this.Controls.Add(this.textAddress);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.lblSalary);
            this.Controls.Add(this.lblDoj);
            this.Controls.Add(this.lblHobbies);
            this.Controls.Add(this.lblSkillSets);
            this.Controls.Add(this.lblQualification);
            this.Controls.Add(this.lblNationality);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.lblName);
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Name = "Form1";
            this.Text = "Registration Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.registrationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainingExampleDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.Label lblQualification;
        private System.Windows.Forms.Label lblSkillSets;
        private System.Windows.Forms.Label lblHobbies;
        private System.Windows.Forms.Label lblDoj;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textAddress;
        private System.Windows.Forms.TextBox textDob;
        private System.Windows.Forms.TextBox textDoj;
        private System.Windows.Forms.TextBox textSalary;
        private System.Windows.Forms.DateTimePicker txtDob;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.ListBox lbQualification;
        private System.Windows.Forms.CheckedListBox lbSkillSets;
        private System.Windows.Forms.CheckBox cbSwimming;
        private System.Windows.Forms.CheckBox cbReading;
        private System.Windows.Forms.CheckBox cbCooking;
        private System.Windows.Forms.CheckBox cbMusic;
        private System.Windows.Forms.CheckBox cbMobile;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.ComboBox cbNationality;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnSp;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnID;
        private System.Windows.Forms.ComboBox cbID;
        private TrainingExampleDataSet trainingExampleDataSet;
        private System.Windows.Forms.BindingSource registrationBindingSource;
        private TrainingExampleDataSetTableAdapters.RegistrationTableAdapter registrationTableAdapter;
        private System.Windows.Forms.Button btnDataset;
    }
}

