﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Windows.Forms;
using EntityLayer;
using BusinessLayer;

namespace UIForm
{
    public partial class Form1 : Form
    {
        RegistrationBAL bal = new RegistrationBAL();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'trainingExampleDataSet.Registration' table. You can move, or remove it, as needed.
            this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Address_Click(object sender, EventArgs e)
        {

        }

        private void lbldob_Click(object sender, EventArgs e)
        {

        }

        private void lblGender_Click(object sender, EventArgs e)
        {

        }

        private void lblNationality_Click(object sender, EventArgs e)
        {

        }

        private void lblSalary_Click(object sender, EventArgs e)
        {

        }

        private void textSalary_TextChanged(object sender, EventArgs e)
        {

        }


        string gender = "";
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = rbMale.Text;

        }

        private void rbFemale_CheckedChanged(object sender, EventArgs e)
        {
            gender = rbFemale.Text;
        }


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            textDob.Text = txtDob.Value.ToShortDateString();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            textDoj.Text = monthCalendar1.SelectionStart.ToShortDateString();
        }
        List<string> hobby = new List<string>();
        private void cbSwimming_CheckedChanged(object sender, EventArgs e)
        {
            if (cbSwimming.Checked)
                hobby.Add(cbSwimming.Text);

            else
                hobby.Remove(cbSwimming.Text);
        }

        private void cbReading_CheckedChanged(object sender, EventArgs e)
        {

            if (cbReading.Checked)
                hobby.Add(cbReading.Text);

            else
                hobby.Remove(cbReading.Text);
        }

        private void cbMobile_CheckedChanged(object sender, EventArgs e)
        {
            if (cbMobile.Checked)
                hobby.Add(cbMobile.Text);

            else
                hobby.Remove(cbMobile.Text);
        }

        private void cbCooking_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCooking.Checked)
                hobby.Add(cbCooking.Text);

            else
                hobby.Remove(cbCooking.Text);

        }

        private void cbMusic_CheckedChanged(object sender, EventArgs e)
        {

            if (cbMusic.Checked)
                hobby.Add(cbMusic.Text);

            else
                hobby.Remove(cbMusic.Text);
        }
        public static string UserName = "";

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
           // this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);
            //passing parameters


            string name = textName.Text;
            if (string.IsNullOrEmpty(name) || string.IsNullOrWhiteSpace(name))
            {
                errorProvider1.SetError(textName, "Name cannot be blank");
            }
            else
                errorProvider1.SetError(textName, string.Empty);

            UserName = name;

            string address = textAddress.Text;
            if (string.IsNullOrEmpty(address) || string.IsNullOrWhiteSpace(address))
            {
                errorProvider1.SetError(textAddress, "Address cannot be blank");
            }
            else
                errorProvider1.SetError(textAddress, string.Empty);


        



          //  string address = textAddress.Text;
            string doj = textDoj.Text;
            string dob = textDob.Text;
            decimal salary = 0.0M;
            bool res = decimal.TryParse(textSalary.Text, out salary);

            if (res == false)
            {
                MessageBox.Show("Salary has to be numeric values");
                return;
            }

            if(rbMale.Checked==false && rbFemale.Checked==false)
            {
                errorProvider1.SetError(rbMale, "Select gender");
                return;
            }


            if (cbNationality.SelectedIndex == -1)
            {
                errorProvider1.SetError(cbNationality, "Select nation from the comobox");
                return;
            }

            else
                errorProvider1.SetError(cbNationality, string.Empty);


            string nation = cbNationality.SelectedItem.ToString();

            // string nation = cbNation.SelectedItem.ToString();
            string q = "";

            foreach (object t in lbQualification.SelectedItems)

                q += t + ",";



            //checkedLIstbox
            string skills = "";
            foreach (var t in lbSkillSets.CheckedItems)
                skills += t + ",";
            //hobby is  List<String>
            string h = "";
            foreach (var s in hobby)
                h += s + ",";

            MessageBox.Show(name + "\n" + address + "\n" + dob + "\n" + gender + "\n" + nation + "\n" + skills + "\n" + q + "\n" + h + "\n" + doj + "\n" + salary);

            RegistrationEntity entity = new RegistrationEntity();
            entity.Name = name;
            entity.Address = address;
            entity.DOB = DateTime.Parse(dob);
            entity.Gender = gender;
            entity.Nationality = nation;
            entity.Quali = q;
            entity.Skills = skills;
            entity.Hobbies = h;
            entity.DOJ = DateTime.Parse(doj);
            entity.Salary = salary;

            try
            {
               
                bool result = bal.InsertRegistration(entity);
                if (result)
                    MessageBox.Show("Data Inserted");
                this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Form2 f2 = new Form2();
            //f2.ShowDialog();//call one form from another form
            ////MessageBox.Show(name+ "\n" );





        }

        private void textAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            //to reset textbox
            textName.Text = "";
            textAddress.Text = string.Empty;
          //  textDob.Text = "";
            textDoj.Text = "";
            textSalary.Text = "";
            cbNationality.SelectedIndex = -1;
            //list box and checked list box
            lbQualification.ClearSelected();
            lbSkillSets.ClearSelected();
            for(int i=0;i<lbSkillSets.Items.Count;i++)
            {
                lbSkillSets.SetItemChecked(i, false);
            }

            //radio button and checkbox

            rbMale.Checked = false;
            rbFemale.Checked = false;
            cbCooking.Checked = false;
            cbSwimming.Checked = false;
            cbMusic.Checked = false;
            cbMobile.Checked = false;
            cbReading.Checked = false;


            txtDob.ResetText();
            textDob.ResetText();
            monthCalendar1.ResetText();
         

           
        }

        private void textName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                var result = bal.SelectRegistration();
                dataGridView1.DataSource = result;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnID_Click(object sender, EventArgs e)
        {

            MessageBox.Show(cbID.SelectedValue.ToString());//for showing the id 


            try
            {
                int id = Convert.ToInt32(cbID.SelectedValue);
                var res=  bal.SeledtByID(id);


                textName.Text = res.Name;//reterving the data from data base & storing in textname
                textAddress.Text = res.Address;
                textDob.Text = res.DOB.ToString();
                textDoj.Text = res.DOJ.ToString();
                cbNationality.Text = res.Nationality;
                textSalary.Text = res.Salary.ToString();
                //cbNationality.Text = res.Nationality();
                //textSalary = res.Salary.ToString();


                //radio button
                if (res.Gender == "Male")
                    rbMale.Checked = true;
                if (res.Gender == "Female")
                    rbFemale.Checked = true;

                //quali listbox

                string []quali=res.Quali.Split(',');
                foreach(var q in quali)
                {
                    for (int i = 0; i < lbQualification.Items.Count; i++)
                        lbQualification.SetSelected(i, true);
                }


                //skillsets
                string[] sk = res.Skills.Split(',');
                foreach(var s in sk)
                {
                    for(int i=0;i<lbSkillSets.Items.Count;i++)
                    {
                        if(lbSkillSets.Items[i].ToString()==s)
                        {
                            lbSkillSets.SetItemChecked(i, true);
                        }
                    }
                }


                string[] hobby = res.Hobbies.Split(',');
                foreach(var h in hobby)
                {
                    if (h == cbCooking.Text)
                        cbCooking.Checked = true;
                    if (h == cbSwimming.Text)
                        cbSwimming.Checked = true;

                    if (h == cbReading.Text)
                        cbReading.Checked = true;

                    if (h == cbMobile.Text)
                        cbMobile.Checked = true;

                    if (h == cbMusic.Text)
                        cbMusic.Checked = true;
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //for updating the value address,skills salary & regid

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string add = textAddress.Text;
                string skills = "";

                foreach(var s in lbSkillSets.CheckedItems)
                {
                    skills += s + ",";
                }
                decimal sal = decimal.Parse(textSalary.Text);
                int regid = Convert.ToInt32(cbID.SelectedValue);


                var res = bal.UpdateRegistration(add, skills, sal, regid);
                    if(res)
                    MessageBox.Show("Data Updated");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
               
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int regid = Convert.ToInt32(cbID.SelectedValue);
                var res = bal.DeleteRegistration(regid);
                if (res)
                    MessageBox.Show("Data deleted");

                this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void btnSp_Click(object sender, EventArgs e)
        {
            try
            {
                string name = textName.Text;
                if (string.IsNullOrEmpty(name) || string.IsNullOrWhiteSpace(name))
                {
                    errorProvider1.SetError(textName, "Name cannot be blank");
                }
                else
                    errorProvider1.SetError(textName, string.Empty);

                UserName = name;

                string address = textAddress.Text;
                if (string.IsNullOrEmpty(address) || string.IsNullOrWhiteSpace(address))
                {
                    errorProvider1.SetError(textAddress, "Address cannot be blank");
                }
                else
                    errorProvider1.SetError(textAddress, string.Empty);






                //  string address = textAddress.Text;
                string doj = textDoj.Text;
                string dob = textDob.Text;
                decimal salary = 0.0M;
                bool res = decimal.TryParse(textSalary.Text, out salary);

                if (res == false)
                {
                    MessageBox.Show("Salary has to be numeric values");
                    return;
                }

                if (rbMale.Checked == false && rbFemale.Checked == false)
                {
                    errorProvider1.SetError(rbMale, "Select gender");
                    return;
                }


                if (cbNationality.SelectedIndex == -1)
                {
                    errorProvider1.SetError(cbNationality, "Select nation from the comobox");
                    return;
                }

                else
                    errorProvider1.SetError(cbNationality, string.Empty);


                string nation = cbNationality.SelectedItem.ToString();

                // string nation = cbNation.SelectedItem.ToString();
                string q = "";

                foreach (object t in lbQualification.SelectedItems)

                    q += t + ",";



                //checkedLIstbox
                string skills = "";
                foreach (var t in lbSkillSets.CheckedItems)
                    skills += t + ",";
                //hobby is  List<String>
                string h = "";
                foreach (var s in hobby)
                    h += s + ",";

                MessageBox.Show(name + "\n" + address + "\n" + dob + "\n" + gender + "\n" + nation + "\n" + skills + "\n" + q + "\n" + h + "\n" + doj + "\n" + salary);

                RegistrationEntity entity = new RegistrationEntity();
                entity.Name = name;
                entity.Address = address;
                entity.DOB = DateTime.Parse(dob);
                entity.Gender = gender;
                entity.Nationality = nation;
                entity.Quali = q;
                entity.Skills = skills;
                entity.Hobbies = h;
                entity.DOJ = DateTime.Parse(doj);
                entity.Salary = salary;

                var id = bal.CallSP_sp_insertregistration(entity);
                if(id>0)
                {
                    MessageBox.Show("Data Inserted");
                    MessageBox.Show("Your RegID is:" + id);


                }
                this.registrationTableAdapter.Fill(this.trainingExampleDataSet.Registration);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDataset_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
      
    

