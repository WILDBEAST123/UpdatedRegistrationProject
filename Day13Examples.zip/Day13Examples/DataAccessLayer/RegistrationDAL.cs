﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityLayer;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class RegistrationDAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader r = null;

       // RegistrationDAL dal = new RegistrationDAL();
       //for updating the database


            public bool DeleteRegistration(int regid)
        {
            try
            {
                con = DBConnect.GetConnection();
                con.Open();
                string query = "Delete from Registration where RegID=@regid";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@regid", regid);
                var res = cmd.ExecuteNonQuery();
                if (res > 0)
                    return true;

            }
            catch(Exception ex)
            {
                throw ex;

            }
            finally
            {
                con.Close();
            }
            return false;
        }
       public bool UpdateRegistration(string add, string skills, decimal sal, int regid)
        {

            try
            {
               // RegistrationEntity entity = new RegistrationEntity();
                con = DBConnect.GetConnection();
                con.Open();
                string query = "update Registration set Address=@add ,Skillsets=@skills,Salary=@sal where RegID=@regid";
              
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@regid", regid);
                cmd.Parameters.AddWithValue("@add", add);
                cmd.Parameters.AddWithValue("@skills", skills);
                cmd.Parameters.AddWithValue("@sal", sal);
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                    return true;

            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return false;

        }

        public bool InsertRegistration(RegistrationEntity entity)
        {
            try
            {
                con = DBConnect.GetConnection();
                con.Open();
                string query = "insert into Registration values(@nm,@add,@dob,@gen,@nat,@q,@sk,@hob,@doj,@sal)";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nm", entity.Name);
                cmd.Parameters.AddWithValue("@add", entity.Address);
                cmd.Parameters.AddWithValue("@dob", entity.DOB);
                cmd.Parameters.AddWithValue("@gen", entity.Gender);
                cmd.Parameters.AddWithValue("@nat", entity.Nationality);
                cmd.Parameters.AddWithValue("@q", entity.Quali);
                cmd.Parameters.AddWithValue("@sk", entity.Skills);
                cmd.Parameters.AddWithValue("@hob", entity.Hobbies);
                cmd.Parameters.AddWithValue("@doj", entity.DOJ);
                cmd.Parameters.AddWithValue("@sal", entity.Salary);
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                    return true;


            }
            catch(SqlException sql)
            {
                throw sql;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return false;

        }

        public RegistrationEntity SeledtByID(int id)
        {
            RegistrationEntity re = new RegistrationEntity();
            try
            {
                con = DBConnect.GetConnection();
                con.Open();
                string query = "select *from Registration where RegID=" + id;
                cmd = new SqlCommand(query, con);
                r = cmd.ExecuteReader();
                if(r.Read())
                {
                    re.RegID = Convert.ToInt32(r[0]);
                    re.Name = r[1].ToString();
                    re.Address = r[2].ToString();
                    re.DOB = Convert.ToDateTime(r[3]);
                    re.Gender = r[4].ToString();
                    re.Nationality = r[5].ToString();
                    re.Quali = r[6].ToString();
                    re.Skills = r[7].ToString();
                    re.Hobbies = r[8].ToString();
                    re.DOJ = Convert.ToDateTime(r[9]);
                    re.Salary = Convert.ToDecimal(r[10]);
                    
                }
                
            }catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
           
            return re;
        }

        public IList<RegistrationEntity>SelectRegistration()
        {
            List<RegistrationEntity> reglst = new List<RegistrationEntity>();
            try
            {
                con = DBConnect.GetConnection();
                con.Open();
                string query = "Select *from Registration";
                cmd = new SqlCommand(query, con);
                r = cmd.ExecuteReader();//r is the object of datareader;
                while(r.Read())
                {
                    RegistrationEntity re = new RegistrationEntity();
                    re.RegID = Convert.ToInt32(r[0]);
                    re.Name = r[1].ToString();
                    re.Address = r[2].ToString();
                    re.DOB = Convert.ToDateTime(r[3]);
                    re.Gender = r[4].ToString();
                    re.Nationality = r[5].ToString();
                    re.Quali = r[6].ToString();
                    re.Skills = r[7].ToString();
                    re.Hobbies = r[8].ToString();
                    re.DOJ = Convert.ToDateTime(r[9]);
                    re.Salary = Convert.ToDecimal(r[10]);
                    reglst.Add(re);

                }
            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return reglst;
        }

        public int CallSP_sp_insertregistration(RegistrationEntity entity)
        {
            int result = 0;
            try
            {
               

                con = DBConnect.GetConnection();
                con.Open();
                string query = "sp_insertregistration";
                cmd = new SqlCommand(query, con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", entity.Name);
                cmd.Parameters.AddWithValue("@add", entity.Address);
                cmd.Parameters.AddWithValue("@dob", entity.DOB);
                cmd.Parameters.AddWithValue("@gen", entity.Gender);
                cmd.Parameters.AddWithValue("@nat", entity.Nationality);
                cmd.Parameters.AddWithValue("@q", entity.Quali);
                cmd.Parameters.AddWithValue("@sk", entity.Skills);
                cmd.Parameters.AddWithValue("@hob", entity.Hobbies);
                cmd.Parameters.AddWithValue("@doj", entity.DOJ);
                cmd.Parameters.AddWithValue("@sal", entity.Salary);
                SqlParameter idparam = new SqlParameter();
                idparam.ParameterName = "@id";//outpur parameter
                idparam.SqlDbType = SqlDbType.Int;
                idparam.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(idparam);
                int res = cmd.ExecuteNonQuery();
                if(res>0)
                {
                    result = Convert.ToInt32(idparam.Value);

                }



            }
            catch(Exception ex)
            {
                throw ex;
            }
            return result;
            
            
            
        }
        public DataSet ShowEmpProject_Report()

        {

            DataSet ds = null;
            SqlDataAdapter adp = null;

            try
            {
                con = DBConnect.GetConnection();
                string query = "Select r.Name,p.Projname from Registration r full outer join ProjectDetails p on r.projid=p.projid";
                adp = new SqlDataAdapter(query, con);
                ds = new DataSet();
                adp.Fill(ds, "RegProj");//name of table inside dataset,dataset name are case sensitive
            }
            catch(SqlException sql)
            {
                throw sql;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return ds;
        }

    }
}
