﻿namespace PIzzahutonline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDeals = new System.Windows.Forms.Button();
            this.btnCarte = new System.Windows.Forms.Button();
            this.btnOns = new System.Windows.Forms.Button();
            this.btnAppetisers = new System.Windows.Forms.Button();
            this.btnPasta = new System.Windows.Forms.Button();
            this.btnBevrages = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.lbDeals = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDeals
            // 
            this.btnDeals.Location = new System.Drawing.Point(12, 55);
            this.btnDeals.Name = "btnDeals";
            this.btnDeals.Size = new System.Drawing.Size(75, 23);
            this.btnDeals.TabIndex = 0;
            this.btnDeals.Text = "Hot Deals";
            this.btnDeals.UseVisualStyleBackColor = true;
            // 
            // btnCarte
            // 
            this.btnCarte.Location = new System.Drawing.Point(93, 55);
            this.btnCarte.Name = "btnCarte";
            this.btnCarte.Size = new System.Drawing.Size(75, 23);
            this.btnCarte.TabIndex = 1;
            this.btnCarte.Text = "A La Carte";
            this.btnCarte.UseVisualStyleBackColor = true;
            // 
            // btnOns
            // 
            this.btnOns.Location = new System.Drawing.Point(174, 55);
            this.btnOns.Name = "btnOns";
            this.btnOns.Size = new System.Drawing.Size(75, 23);
            this.btnOns.TabIndex = 2;
            this.btnOns.Text = "Add Ones";
            this.btnOns.UseVisualStyleBackColor = true;
            // 
            // btnAppetisers
            // 
            this.btnAppetisers.Location = new System.Drawing.Point(255, 55);
            this.btnAppetisers.Name = "btnAppetisers";
            this.btnAppetisers.Size = new System.Drawing.Size(75, 23);
            this.btnAppetisers.TabIndex = 3;
            this.btnAppetisers.Text = "Appetisers";
            this.btnAppetisers.UseVisualStyleBackColor = true;
            // 
            // btnPasta
            // 
            this.btnPasta.Location = new System.Drawing.Point(336, 55);
            this.btnPasta.Name = "btnPasta";
            this.btnPasta.Size = new System.Drawing.Size(75, 36);
            this.btnPasta.TabIndex = 4;
            this.btnPasta.Text = "Baked Pasta/Rice";
            this.btnPasta.UseVisualStyleBackColor = true;
            // 
            // btnBevrages
            // 
            this.btnBevrages.Location = new System.Drawing.Point(417, 55);
            this.btnBevrages.Name = "btnBevrages";
            this.btnBevrages.Size = new System.Drawing.Size(75, 23);
            this.btnBevrages.TabIndex = 5;
            this.btnBevrages.Text = "Beverages";
            this.btnBevrages.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(526, 55);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // lbDeals
            // 
            this.lbDeals.AutoSize = true;
            this.lbDeals.Location = new System.Drawing.Point(12, 104);
            this.lbDeals.Name = "lbDeals";
            this.lbDeals.Size = new System.Drawing.Size(54, 13);
            this.lbDeals.TabIndex = 7;
            this.lbDeals.Text = "Hot Deals";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(27, 158);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(141, 50);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(312, 158);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(141, 50);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 257);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "label1";
// this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(333, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(603, 460);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbDeals);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btnBevrages);
            this.Controls.Add(this.btnPasta);
            this.Controls.Add(this.btnAppetisers);
            this.Controls.Add(this.btnOns);
            this.Controls.Add(this.btnCarte);
            this.Controls.Add(this.btnDeals);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDeals;
        private System.Windows.Forms.Button btnCarte;
        private System.Windows.Forms.Button btnOns;
        private System.Windows.Forms.Button btnAppetisers;
        private System.Windows.Forms.Button btnPasta;
        private System.Windows.Forms.Button btnBevrages;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label lbDeals;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

